require 'test_helper'

class MemberHelperTest < ActionView::TestCase
end
