require 'test_helper'

class RoomHelperTest < ActionView::TestCase
end
