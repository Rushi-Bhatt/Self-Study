require 'test_helper'

class BookingHelperTest < ActionView::TestCase
end
