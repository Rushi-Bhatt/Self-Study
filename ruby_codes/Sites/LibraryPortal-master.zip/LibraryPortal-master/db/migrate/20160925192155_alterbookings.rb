class Alterbookings < ActiveRecord::Migration
  def change
  #  add_column :bookings, :slot, :integer
  #  add_column :bookings, :date, :date
  end
end
